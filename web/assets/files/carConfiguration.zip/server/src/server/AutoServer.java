package server;

import java.util.Properties;

import model.Automobile;

/**
 * 
 * This is a interface for server to provide automobile services.
 *
 */

public interface AutoServer {
    public Automobile acceptClientPropertiesObject(Properties properties);
    public String listAutomobiles();
}
