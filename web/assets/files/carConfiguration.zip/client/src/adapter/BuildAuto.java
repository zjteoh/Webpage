package adapter;

import scale.EditThread;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, FixAuto, EditThread {
    // Empty class for extensibility.
    // Implementation details are in ProxyAutomobile.
}
