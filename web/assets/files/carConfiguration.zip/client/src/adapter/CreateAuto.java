package adapter;

public interface CreateAuto {
    
    public void buildAuto(String fileName, String fileType);
    
    public void printAuto(String modelName);
}
