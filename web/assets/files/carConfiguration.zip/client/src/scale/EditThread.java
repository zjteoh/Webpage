package scale;
/**
 * 
 * Provide an interface for editOptions
 * The implementations are in ProxyAutomobile abstract class
 */
public interface EditThread {
    public void editOptionSetName(String model, String name, String newName);
    public void editOptionName(String model, String optionSetName, String optionName, String newOptionName);
    public void editOptionValue(String model, String optionSetName, String optionName, double newValue);
}
