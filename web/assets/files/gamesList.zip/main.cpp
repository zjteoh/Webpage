#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "BinarySearchTree.h"
#include "Game.h"
#include "Hash.h"
#include <cmath>

#define INPUT_FILE "text.txt"
#define OUTPUT_FILE "output.txt"

using namespace std;

void showMenu();
void requestAction(Hash<Game> *gameHash, BinarySearchTree<Game> * gameTree, BinarySearchTree<GameName> * gameTree2);
bool readFile(Hash<Game> *gameHash, BinarySearchTree<Game> * gameTree, BinarySearchTree<GameName> * gameTree2, const char* filename);
void displayTraversal(Game &anItem);
void displayTraversal(GameName &anItem);
void writeToFile(BinarySearchTree<Game> * gameTree);
void outFileDisplay(Game &game, ofstream & outFile);
int getNextPrime(int a);

int main()
{

	Hash<Game> *gameHash = new Hash<Game>;
    BinarySearchTree<Game> *gameTree = new BinarySearchTree<Game>;
	BinarySearchTree<GameName> *gameTree2 = new BinarySearchTree<GameName>;


    bool quitOrContinue = false;
	quitOrContinue = readFile(gameHash, gameTree, gameTree2, INPUT_FILE);
	if(quitOrContinue == false)
		return 0;

    showMenu();
    requestAction(gameHash, gameTree,gameTree2);

}

void displayTraversal(Game &anItem)
{
	cout << anItem.getName() << endl;
}

void displayTraversal(GameName &anItem)
{
	cout << anItem.getName() << endl;
}

void outFileDisplay(Game & game, ofstream & outFile)
{
	outFile << game.getKey() << ";" << game.getName() << ";" << game.getDeveloper() << ";" << game.getPublisher() << ";" << game.getReleaseYear() << ";" << game.getGenre() << endl;
	//return;
}

int getNextPrime(int a)
{
	int i, j, count;
	for (i = a + 1; 1; i++)
	{
		count = 0;
		for (j = 2; j < i; j++)
		{
			if (i%j == 0) // found a devisor
			{
				count++;
				break;  // break for (j = 2,j < i; j++) loop
				// this will speed up a bit
			}
		}
		if (count == 0)
		{
			return i;
			//break; // break for (i = a + 1; 1; i++) loop
			// break is not needed because return will stop execution of this function
		}
	}
}

bool readFile(Hash<Game> *gameHash, BinarySearchTree<Game> * gameTree, BinarySearchTree<GameName> * gameTree2, const char* filename) {
    ifstream inFile;
	string line, name, developer, publisher, delim = ";",test;
	int numoflines = 0;
    bool empty = true;

	inFile.open(filename);
	if (!inFile)
	{
		cout << "Error opening file " << filename << endl;
		return false;
	}
	else
	{
		while (getline(inFile, test))
		{
			numoflines++;
		}
		inFile.close();

		numoflines = getNextPrime(numoflines);

		gameHash->setHashSize(numoflines);

		inFile.open(filename);

		while (getline(inFile, line))
		{
			string key_str = line.substr(0, line.find(delim));
			int key = atoi(key_str.c_str());
			line.erase(0, line.find(delim) + delim.length());

			string name = line.substr(0, line.find(delim));
			line.erase(0, line.find(delim) + delim.length());

			string developer = line.substr(0, line.find(delim));
			line.erase(0, line.find(delim) + delim.length());

			string publisher = line.substr(0, line.find(delim));
			line.erase(0, line.find(delim) + delim.length());

			string year_str = line.substr(0, line.find(delim));
			int year = atoi(year_str.c_str());
			line.erase(0, line.find(delim) + delim.length());

			string genre = line.substr(0, line.find(delim));
			line.erase(0, line.find(delim) + delim.length());

			Game* game = new Game(key, name, developer, publisher, year, genre);

			gameHash->insert(*game, key);
			gameTree->insert(*game);
			gameTree2->insert(*game);

			empty = false;
		}

		inFile.close();
		return true;
	}
}
//write to output file by preOrder traversal
void writeToFile(BinarySearchTree<Game> * countyTree)
{
	ofstream outFile(OUTPUT_FILE);

	if (outFile.is_open())
	{
		cout << "Output is written to file \"output.txt\" by preOrder-traversal"<< endl;
		countyTree->preOrder_outFile(outFileDisplay, outFile);
		outFile.close();
	}
	else
		cout << "File not found" << endl;

	cout << endl;
}


//shows the user what functions can be called
void showMenu()
{
    cout << "S - Search" << endl
    << "P - Print" << endl
    << "I - Insert Game" << endl
    << "D - Delete Game" << endl
    << "H - Help to show Menu" << endl
	<< "W - Write data to file" << endl
	<< "T - Statistics" << endl
    << "Q - Quit" << endl;
}

// asks the user for an action and calls the functions to process
void requestAction(Hash<Game> *gameHash, BinarySearchTree<Game> * gameTree,BinarySearchTree<GameName> * gameTree2)
{
    string userInput;
    do{
        cout << "What would you like to do? ";

        getline(cin,userInput);
        userInput[0] = toupper(userInput[0]);
        cout << endl;
		if (userInput == "S" || userInput == "P" || userInput == "I" || userInput == "D" || userInput == "A" || userInput == "H" || userInput == "Q" || userInput == "W" || userInput == "T")
        {
			bool done = false;
            if( userInput=="S")
            {
				do
				{
					string user;
					cout << "Search by:" << endl
					<< "I - Game ID" << endl
					<< "N - Game Name" << endl
					<< "B - BACK" << endl;
					cin >> user;
					cin.get();
					userInput = toupper(user[0]);
					if (userInput == "I")
					{
						int key;
						cout << "Enter game ID = ";
						cin >> key;
						Game* found = gameHash->search(key);

						if (found)
                        {
							cout << "Game Found!" << endl
                            << "Game Key: " << found->getKey() << endl
                            << "Name: " << found->getName() << endl
                            << "Developer: " << found->getDeveloper() << endl
                            << "Publisher: " << found->getPublisher() << endl
                            << "Genre: " << found->getGenre() << endl
                            << "Release Year: " << found->getReleaseYear() << endl;
                        }
						else
							cout << "Game not found" << endl;
						cin.get();
						cout << endl;

					}
					else if (userInput == "N")
					{
						cout << "Enter game name = ";
						string name;
						getline(cin, name);
						GameName game;
						bool found = gameTree2->getEntry(Game(0,name,"","",0,""), game);

						if (found)
						{
							cout << "Game found!" <<endl << game << endl;
                            //cout << game.getName <<endl;
						}
						else
							cout << "Game not found" << endl;

					}
					else if (userInput == "B")
						done = true;
					else
					{
						cout << "Please enter the right choice" << endl;
					}
				} while (done == false);
            }
            else if( userInput=="P")
            {
				cout << "A - Preorder traversal" << endl;
				cout << "B - Inorder traversal" << endl;
				cout << "C - Postorder traversal" << endl;
				cout << "D - Indented tree" << endl;
				cout << "E - Breath-First traversal" << endl;
				cout << "F - Hash display (unsorted)" << endl;
				cout << "G - BACK" << endl;

				string choice;
                //string userInput;
				bool repeat = false;

				do
				{
                    getline(cin,choice);
                    choice[0]= toupper(choice[0]);

					if (choice == "A")
					{
						cout << "1 - By key" << endl
							<<  "2 - By name" << endl;
						cout << "Enter choice = ";
						int in;
						cin >> in;
						if (in == 1)
							gameTree->preOrder(displayTraversal);
						else if (in == 2)
							gameTree2->preOrder(displayTraversal);
						else
							cout << "Wrong input" << endl;
					}
					else if (choice == "B")
					{
						cout << "1 - By key" << endl
							<< "2 - By name" << endl;
						cout << "Enter choice = ";
						int in;
						cin >> in;
						if (in == 1)
							gameTree->inOrder(displayTraversal);
						else if (in == 2)
							gameTree2->inOrder(displayTraversal);
						else
							cout << "Wrong input" << endl;
					}
					else if (choice == "C")
					{
						cout << "1 - By key" << endl
							<< "2 - By name" << endl;
						cout << "Enter choice = ";
						int in;
						cin >> in;
						if (in == 1)
							gameTree->postOrder(displayTraversal);
						else if (in == 2)
							gameTree2->postOrder(displayTraversal);
						else
							cout << "Wrong input" << endl;
					}
					else if (choice == "D")
					{
						cout << "1 - By key" << endl
							<<  "2 - By name" << endl;
						cout << "Enter choice = ";
						int in;
						cin >> in;
						if (in == 1)
							gameTree->PrintIndentedTree(displayTraversal);
						else if (in == 2)
							gameTree2->PrintIndentedTree(displayTraversal);
						else
							cout << "Wrong input" << endl;
					}
					else if (choice == "E")
					{
						cout << "1 - By key" << endl
							<< "2 - By name" << endl;
						cout << "Enter choice = ";
						int in;
						cin >> in;
						if (in == 1)
							gameTree->BreadthFirstTraversal(displayTraversal);
						else if (in == 2)
							gameTree2->BreadthFirstTraversal(displayTraversal);
						else
							cout << "Wrong input" << endl;
					}
					else if (choice == "F")
						gameHash->display(displayTraversal);
					else if(choice == "G")
						repeat = true;
					else
                    {
                        cout << "Wrong choice" << endl << "Enter a choice: ";
                    }

					if (choice == "A" || choice == "B" || choice == "C" || choice == "D" || choice == "E" || choice == "F")
                    {
                        repeat = true;
                    }

					cout << endl;
				} while (repeat == false);

            }
            else if( userInput=="I")
            {
                string gameName, publisherName, developerName, genre, yearString, keyString;
                int year, key;
                bool isNum;
				cout << "Enter game name = ";
                getline(cin,gameName);
				cout << "Enter publisher name = ";
				getline(cin,publisherName);
				cout << "Enter developer name = ";
				getline(cin,developerName);
                do{
                    isNum = true;
                    cout << "Please enter a numeric key = ";
                    getline(cin,keyString);
                    for(int i=0; i<keyString.length();i++)
                    {
                        if(!isdigit(keyString[i]))
                        {
                            isNum = false;
                        }
                    }
                }
                while(!isNum);
                key = atoi(keyString.c_str());

                do{
                    isNum = true;
                    cout << "Please enter a numeric year released = ";
                    getline(cin,yearString);
                    for(int i=0; i<yearString.length();i++)
                    {
                        if(!isdigit(yearString[i]))
                        {
                            isNum = false;
                        }
                    }
                }
                while(!isNum);
                year = atoi(yearString.c_str());

				cout << "Enter genre = ";
				getline(cin, genre);

				Game *game = new Game(key, gameName, developerName, publisherName, year, genre);
				gameHash->insert(*game,key);
				gameTree->insert(*game);
				gameTree2->insert(*game);
            }
            else if( userInput=="D")
            {
				int key;
				cout << "Please enter the game key = ";
				cin >> key;

				Game game(key, "", "", "", 0, "");
				bool trueFalse = gameTree->remove(game);

				if (trueFalse == true)
					cout << "Game deleted" << endl;
				else
					cout << "Game not found" << endl;

            }
            else if( userInput=="H")
            {
                showMenu();
            }
            else if( userInput=="A")
            {
                cout << "Developed by Alice Ma, Fallaye Diallo, Steven Uehara, Zhi Jia Teoh" << endl;
            }
			else if (userInput == "W")
			{
				writeToFile(gameTree);
			}
			else if (userInput == "T")
			{
				cout << "Hash table" << endl;
				cout << "Hash Size	= " << gameHash->getSize() << endl;
				cout << "Bucket Size	= " << gameHash->getBucket() << endl;
				cout << "Load factor: " << gameHash->getLoad() << endl;
				cout << "Collision	= " << gameHash->getCollision() << endl;
				cout << "Overflow slots filled: " << gameHash->getOverflow() << endl << endl;
			}
        }
        else
        {
            cout << "Please enter a valid command. Press H to show the menu again." << endl;
        }

    }
    while (userInput!="Q");

    if( userInput=="Q")
    {
    	cout << "Quitting Program" << endl;
        gameTree->clear();
		gameTree2->clear();
		delete gameHash;
    }
}
