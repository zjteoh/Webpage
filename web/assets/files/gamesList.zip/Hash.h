using namespace std;

template<class T>
class Hash
{
private:
	int size;

	struct Node
	{
		T* object = NULL;
		int HashU_Key = -1;
	};

	struct Bucket
	{
		Node* bucket = new Node[3];
		Node* overflow;
		int arySize = 5;
		int count = 0;
	};
	Bucket* table;
	Bucket* reHashTable;

	double load;
	int collision = 0;
	int numNode = 0;
	int overflowed = 0;
	bool Delete(T* obj, int U_Key);

public:
	Hash();
	~Hash();
	int getSize(){ return size; }
	int getBucket() { return 3; }
	double getLoad(){return load;}
	int getOverflow(){return overflowed;}
	bool insert(T& obj, int U_Key);
	bool ReHashInsert(T& obj, int U_Key);
	bool reqDelete(T& obj, int U_Key);
	T* search(int U_Key);
	void display(void visit(T& obj)) const;
	void setHashSize(int size);
	int getCollision() { return collision; }
    void ReHash();
};

template<class T>
Hash<T>::Hash()
{}

template<class T>
Hash<T>::~Hash()
{
    for(int i = 0; i < size; i++)
    {
        for(int k = 0; k < table[i].count; k++)
        {
            delete table[i].bucket[k].object;
        }
        delete[] table[i].bucket;
    }
    delete[] table;
}

template<class T>
void Hash<T>::setHashSize(int size)
{
	this->size = size;
	table = new Bucket[size];
}

template<class T>
bool Hash<T>::insert(T& obj, int U_Key)
{
	Node newNode;
	int index;
	newNode.object = &obj;
	index = U_Key % size;
	newNode.HashU_Key = U_Key;
	if (table[index].count != 0 && table[index].count % 3 == 0)
	{
		table[index].overflow = new Node[table[index].arySize];
		for (int i = 0; i < table[index].arySize; i++)
		{
			table[index].overflow[i] = table[index].bucket[i];
		}
		delete[] table[index].bucket;
		table[index].arySize += 5;
		table[index].bucket = new Node[table[index].arySize];
		for (int i = 0; i < table[index].arySize; i++)
		{
			table[index].bucket[i] = table[index].overflow[i];
		}
	}
	if (table[index].count > 0)
	{
		collision++;
	}
	table[index].bucket[table[index].count] = newNode;
	table[index].count++;
	if(table[index].count > 3)
    {
        overflowed++;
    }
	numNode++;
	double buff = numNode - collision;
	load = buff / size * 100;
	if(load > 75.0)
    {
        ReHash();
    }
	return true;
}

template<class T>
bool Hash<T>::ReHashInsert(T& obj, int U_Key)
{
	Node newNode;
	int index;
	newNode.object = &obj;
	index = U_Key % size;
	newNode.HashU_Key = U_Key;
	if (reHashTable[index].count != 0 && reHashTable[index].count % 3 == 0)
	{
		reHashTable[index].overflow = new Node[reHashTable[index].arySize];
		for (int i = 0; i < reHashTable[index].arySize; i++)
		{
			reHashTable[index].overflow[i] = reHashTable[index].bucket[i];
		}
		delete[] reHashTable[index].bucket;
		reHashTable[index].arySize += 5;
		reHashTable[index].bucket = new Node[reHashTable[index].arySize];
		for (int i = 0; i < reHashTable[index].arySize; i++)
		{
			reHashTable[index].bucket[i] = reHashTable[index].overflow[i];
		}
	}
	if (reHashTable[index].count > 0)
	{
		collision++;
	}
	reHashTable[index].bucket[reHashTable[index].count] = newNode;

	reHashTable[index].count++;
	numNode++;
	double buff = numNode - collision;
	load = buff / size * 100;
	if(load > 75.0)
    {
        ReHash();
    }
	return true;
}

template<class T>
bool Hash<T>::reqDelete(T& obj, int U_Key)
{
	T* searchObj;
	searchObj = search(U_Key);
	Delete(searchObj, U_Key);
	return true;
}

template<class T>
bool Hash<T>::Delete(T* obj, int U_Key)
{
	if (obj == NULL)
	{
		return false;
	}

	else
	{
		int index = U_Key % size;
		int lastIndex = table[index].count - 1;
		for (int i = 0; i < table[index].count; i++)
		{
			if (table[index].bucket[i].object == obj)
			{
				if (table[index].count > 1)
				{
					collision--;
				}
				delete table[index].bucket[i].object;
				if (&table[index].bucket[i] != &table[index].bucket[lastIndex])
				{
					table[index].bucket[i] = table[index].bucket[lastIndex];
				}
				delete table[index].bucket[lastIndex].object;
				numNode--;
				table[index].count--;
				return true;
			}
		}
		cout << "Failed" << endl;
		return false;
	}
}

template<class T>
void Hash<T>::display(void visit(T& obj)) const
{
	int cou;
	for (int i = 0; i < size; i++)
	{
		cou = table[i].count;
		if (cou > 0)
		{
			for (int k = 0; k < cou; k++)
			{
				visit(*table[i].bucket[k].object);
			}
		}
	}
}

template<class T>
T* Hash<T>::search(int U_Key)
{
	T* search = NULL;
	int index;
	index = U_Key % size;
	for (int i = 0; i < table[index].count; i++)
	{
		if (table[index].bucket[i].HashU_Key == U_Key)
		{
			search = table[index].bucket[i].object;
			return search;
		}
	}
	return search;
}

template<class T>
void Hash<T>::ReHash()
{
	int track, oldSize = size;
	size *= 2;

    reHashTable = new Bucket[size];
	for (int i = 0; i < oldSize; i++)
	{
		track = table[i].count;
		for (int k = 0; k < track; k++)
		{
			ReHashInsert(*table[i].bucket[k].object, table[i].bucket[k].HashU_Key % size);
		}
		delete[] table[i].bucket;
	}
	delete[] table;

	table = new Bucket[size];
	for (int i = 0; i < size; i++)
	{
		track = table[i].count;
		for (int k = 0; k < track; k++)
		{
			insert(*reHashTable[i].bucket[k].object, reHashTable[i].bucket[k].HashU_Key % size);
		}
		delete[] reHashTable[i].bucket;
	}
	delete[] reHashTable;

}

