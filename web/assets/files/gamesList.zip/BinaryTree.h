// Binary tree abstract base class
// Created by Frank M. Carrano and Tim Henry.
// Modified by:

#include <algorithm>
#include <cmath>
#ifndef _BINARY_TREE
#define _BINARY_TREE
#include "BinaryNode.h"
#include "Queue.h"
using namespace std;

template<class ItemType>
class BinaryTree
{
protected:
    int count;							// number of nodes in tree
	BinaryNode<ItemType>* rootPtr;		// ptr to root node
    int getHeightHelper(BinaryNode<ItemType>* subTreePtr) const;

public:
	// "admin" functions
 	BinaryTree() {rootPtr = 0; count = 0;}
	BinaryTree(const BinaryTree<ItemType> & tree){rootPtr=copyTree(tree.rootPtr); }
    virtual ~BinaryTree() { destroyTree(rootPtr);}
	BinaryTree & operator = (const BinaryTree & sourceTree);
   
	// common functions for all binary trees
 	bool isEmpty() const	{return count == 0;}
	int size() const	    {return count;}
	void clear()			{destroyTree(rootPtr); rootPtr = 0; count = 0;}
	void preOrder(void visit(ItemType &)) const {_preorder(visit, rootPtr);}
	void inOrder(void visit(ItemType &)) const  {_inorder(visit, rootPtr);}
	void postOrder(void visit(ItemType &)) const{_postorder(visit, rootPtr);}
	bool PrintIndentedTree(void visit(ItemType &));
	bool BreadthFirstTraversal(void visit(ItemType &));
    int getHeight() const;
	const int getFilledNodes() const { int fill = 0; _setFilled(rootPtr, fill); return fill; }
	const int getEmptyNodes() const { int empty = 0; _setEmpty(rootPtr, empty); return empty; }
	const int getFullTreeSize() const { int size = 0; _setFullTreeSize(rootPtr, size); return size; }

	//outfile
	void preOrder_outFile(void visit_outFile(ItemType &, ofstream & outFile), ofstream & outFile)const {_preorderOutFile(visit_outFile, rootPtr, outFile);}

	// abstract functions to be implemented by derived class
	virtual bool insert(const ItemType & newData) = 0; 
	virtual bool remove(const ItemType & data) = 0; 
	virtual bool getEntry(const ItemType & anEntry,ItemType & returnedItem) const=0;
    
    
private:   
	// delete all nodes from the tree
	void destroyTree(BinaryNode<ItemType>* nodePtr);

	// copy from the tree rooted at nodePtr and returns a pointer to the copy
	BinaryNode<ItemType>* copyTree(const BinaryNode<ItemType>* nodePtr);

	// internal traverse
	void _preorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const;
	void _inorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const;
	void _postorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const;
	void _printIndented(BinaryNode<ItemType>* nodePtr, int level, int space, void visit(ItemType &));
    void makeEmpty(BinaryTree<ItemType> * &t);

	//statistics 
	void _setFilled(const BinaryNode<ItemType>* nodePtr, int& filled) const;
	void _setEmpty(const BinaryNode<ItemType>* nodePtr, int& empty) const;
	void _setFullTreeSize(const BinaryNode<ItemType>*, int&) const;


	//outfile
	void _preorderOutFile(void visit_outFile(ItemType &, ofstream & outFile), BinaryNode<ItemType>* nodePtr, ofstream & outFile) const;
    
};
/////////////////////////// Implementation //////////////////////////////
template<class ItemType>
bool BinaryTree<ItemType>::PrintIndentedTree(void visit(ItemType &))
{
	if (!rootPtr)
		return false;
	int level = 1, space = 0;
	_printIndented(rootPtr, level, space, visit);
	return true;
}
//function to print indented tree
template<class ItemType>
void BinaryTree<ItemType>::_printIndented(BinaryNode<ItemType>* nodePtr, int level, int space, void visit(ItemType &))
{
	if (!nodePtr)
	{
		return;
	}
	ItemType item = nodePtr->getItem();
	cout << setw(space) << level << ".";
	visit(item);
	_printIndented(nodePtr->getLeftPtr(), ++level, space = space + 3, visit);
	_printIndented(nodePtr->getRightPtr(), level, space, visit);
}


template<class ItemType>
BinaryNode<ItemType>* BinaryTree<ItemType>::copyTree(const BinaryNode<ItemType>* nodePtr) 
{
	BinaryNode<ItemType>* newNodePtr = 0;
    
    // Copy tree nodes during a preorder traversal
    if (nodePtr != nullptr) {
        // Copy node
        newNodePtr = new BinaryNode<ItemType>(nodePtr->getItem(), nullptr, nullptr);
        newNodePtr->setLeftPtr(copyTree(nodePtr->getLeftPtr()));
        newNodePtr->setRightPtr(copyTree(nodePtr->getRightPtr()));}//end if
    // Else tree is empty (newTreePtr is nullptr)
    return newNodePtr;
}

template<class ItemType>
void BinaryTree<ItemType>::destroyTree(BinaryNode<ItemType>* nodePtr)
{
    if (nodePtr != nullptr) {
        destroyTree(nodePtr->getLeftPtr());
        destroyTree(nodePtr->getRightPtr());
        delete nodePtr;
    } // end if
} // end destroyTree

template<class ItemType>
void BinaryTree<ItemType>::_preorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const
{
	if (nodePtr != 0)
	{
		ItemType item = nodePtr->getItem();
		visit(item);
		_preorder(visit, nodePtr->getLeftPtr());
		_preorder(visit, nodePtr->getRightPtr());
	} 
}  

template<class ItemType>
void BinaryTree<ItemType>::_inorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const
{
    if (nodePtr != 0)
    {
        _inorder(visit, nodePtr->getLeftPtr());
        ItemType item = nodePtr->getItem();
        visit(item);
        _inorder(visit, nodePtr->getRightPtr());
    }
}  

template<class ItemType>
void BinaryTree<ItemType>::_postorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const
{
    if (nodePtr != 0)
    {
        _postorder(visit, nodePtr->getLeftPtr());
        _postorder(visit, nodePtr->getRightPtr());
        ItemType item = nodePtr->getItem();
        visit(item);

    }
}

template<class ItemType>
int BinaryTree<ItemType>::getHeightHelper(BinaryNode<ItemType>* subTreePtr) const {
    if (subTreePtr == nullptr) return 0;
    else
        return 1 + max(getHeightHelper(subTreePtr->getLeftPtr()),
                       getHeightHelper(subTreePtr->getRightPtr()));
} // end getHeightHelper

template<class ItemType>
int BinaryTree<ItemType>::getHeight() const{
    return getHeightHelper(rootPtr);
}//end getHeight

template<class ItemType>
BinaryTree<ItemType> & BinaryTree<ItemType>::operator=(const BinaryTree<ItemType> & sourceTree)
{
    if(this != sourceTree){
        makeEmpty();
        if(sourceTree->rootPtr != nullptr){
            rootPtr = copyTree(sourceTree->rootPtr);
        }
    }

    return *sourceTree;
}

//Make tree rooted at t empty, freeing nodes;
// and setting t to null;
template<class ItemType>
void BinaryTree<ItemType>::makeEmpty(BinaryTree<ItemType> * &t){
    if(t != nullptr){
        makeEmpty(t->getLeftChildPtr);
        makeEmpty(t->getRightChildPtr());
        delete t;
        t = nullptr;
    }
}

template<class ItemType>
bool BinaryTree<ItemType>::BreadthFirstTraversal(void visit(ItemType &))
{
	if (!rootPtr)
		return false;

	Queue<BinaryNode<ItemType>*> queue;
	queue.enqueue(rootPtr);
	while (!queue.isEmpty())
	{
		BinaryNode<ItemType>*nodePtr;
		queue.queueFront(nodePtr);
		ItemType item = nodePtr->getItem();
		visit(item);

		if (nodePtr->getLeftPtr())
			queue.enqueue(nodePtr->getLeftPtr());

		if (nodePtr->getRightPtr())
			queue.enqueue(nodePtr->getRightPtr());
		queue.dequeue(nodePtr);
	}
	return true;
}

template<class ItemType>
void BinaryTree<ItemType>::_preorderOutFile(void visit_outFile(ItemType &, ofstream & outFile), BinaryNode<ItemType>* nodePtr, ofstream & outFile) const
{
	if (nodePtr != 0)
	{
		ItemType item = nodePtr->getItem();
		visit_outFile(item, outFile);
		_preorderOutFile(visit_outFile, nodePtr->getLeftPtr(), outFile);
		_preorderOutFile(visit_outFile, nodePtr->getRightPtr(), outFile);
	}
}

template<class ItemType>
void BinaryTree<ItemType>::_setFilled(const BinaryNode<ItemType>* nodePtr, int& fill) const {
	if (!nodePtr)
		return;

	fill++;
	_setFilled(nodePtr->getRightPtr(), fill);
	_setFilled(nodePtr->getLeftPtr(), fill);
}

template<class ItemType>
void BinaryTree<ItemType>::_setEmpty(const BinaryNode<ItemType>* nodePtr, int& empty) const {
	if (!nodePtr) {
		empty++;
		return;
	}

	_setEmpty(nodePtr->getRightPtr(), empty);
	_setEmpty(nodePtr->getLeftPtr(), empty);
}


template<class ItemType>
void BinaryTree<ItemType>::_setFullTreeSize(const BinaryNode<ItemType>* nodePtr, int& size) const {

	size++;

	if (!nodePtr)
		return;

	_setFullTreeSize(nodePtr->getRightPtr(), size);
	_setFullTreeSize(nodePtr->getLeftPtr(), size);
}

#endif

