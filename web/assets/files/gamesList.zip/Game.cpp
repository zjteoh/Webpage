#include "Game.h"

Game::Game(){}

Game::Game(int gId, string gName, string gDeveloper, string gPublisher, int gReleaseYear, string gGenre)
{
	ID = gId; name = gName; developer = gDeveloper; publisher = gPublisher; genre = gGenre; release_year = gReleaseYear;
}

bool Game::operator>(const Game right) const
{
	if (this->getKey() > right.getKey())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Game::operator<(const Game right)const
{
	if (this->getKey() < right.getKey())
	{
		return true;
	}
	else
	{
		return false;
	}

	}
	bool Game::operator==(const Game right)const
	{
	if (this->getKey() == right.getKey()){
		return true;
	}
	else
	{
		return false;
	}
}