#include "Game.h"

GameName::GameName()
{}

GameName::GameName(const Game &game)
{
	*this = game;
}

bool GameName::operator>(const Game &right) const
{
	string l = getName();
	string r = right.getName();

	for (int i = l.size() - 1 ; i >= 0; i--)
	{
		l[i] = tolower(l[i]);
	}

	for (int i = r.size() - 1; i >= 0; i--)

	{
		r[i] = tolower(r[i]);
	}


	if (l > r){
		return true;
	}
	else
	{
		return false;
	}
}
bool GameName::operator<(const Game &right) const
{
	string l = getName();
	string r = right.getName();

	for (int i = l.size() - 1; i >= 0; i--)
	{
		l[i] = tolower(l[i]);
	}

	for (int i = r.size() - 1; i >= 0; i--)
	{
		r[i] = tolower(r[i]);
	}

	if (l < r){
		return true;
	}
	else
	{
		return false;
	}
}
bool GameName::operator==(const Game &right)const
{
	string l = getName();
	string r = right.getName();

	for (int i = l.size() - 1; i >= 0; i--)
	{
		l[i] = tolower(l[i]);
	}

	for (int i = r.size() - 1; i >= 0; i--)
	{
		r[i] = tolower(r[i]);
	}

	if (l == r){
		return true;
	}
	else
	{
		return false;
	}
	

}

void GameName::operator = (const Game& game) {
	this->ID = game.getKey();
	this->name = game.getName();
	this->developer = game.getDeveloper();
	this->publisher = game.getPublisher();
	this->genre = game.getGenre();
	this->release_year = game.getReleaseYear();
}

