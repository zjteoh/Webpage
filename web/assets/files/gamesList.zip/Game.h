//A class for the data type Game
#include <string>
#include <iostream>

using namespace std;
class Game{

protected:
	int ID;
	string name;
	string developer;
	string publisher;
	int release_year;
	string genre;

public:
	Game();
	Game(int gId, string gName, string gDeveloper, string gPublisher, int gReleaseYear, string gGenre);
	//setter
	void setDeveloper(string dev){developer = dev;}
	void setReleaseYear(int year){release_year = year;}

	//getter
	int getKey() const { return ID; }
	string getName() const { return name; }
	string getDeveloper() const { return developer; }
	string getPublisher() const {return publisher;}
	string getGenre() const { return genre; }
    int getReleaseYear() const { return release_year;}

	friend ostream & operator<<(ostream &os, const Game& g) 
	{
		return os << g.getKey() << ", " <<g.getName() << ", " << g.getPublisher() << ", " << g.getDeveloper() << ", " << g.getReleaseYear() << ", " << g.getGenre();
	}
    
	bool operator>(const Game right) const;
    bool operator<(const Game right)const;
	bool operator==(const Game right)const;
};


class GameName :public Game 
{
public:
	GameName();
	GameName(const Game &game);
	bool operator>(const Game &right) const;
	bool operator<(const Game &right) const;
	bool operator==(const Game &right)const;
	void operator = (const Game& game);

	friend ostream & operator<<(ostream &os, const GameName& g)
	{
        return os << "Game Key: " << g.getKey() << endl
        << "Name: " << g.getName() << endl
        << "Developer: " << g.getDeveloper() << endl
        << "Publisher: " << g.getPublisher() << endl
        << "Genre: " << g.getGenre() << endl
        << "Release Year: " << g.getReleaseYear() << endl;
        
		/*return os << g.getKey() << ", " << g.getName() << ", " << g.getPublisher() << ", " << g.getDeveloper() << ", " << g.getReleaseYear() << ", " << g.getGenre();*/
        //return os << g;
	}
};